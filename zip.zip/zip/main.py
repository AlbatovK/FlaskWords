from flask import Flask, render_template, redirect

from decision_form import DecisionForm
from question_form import QuestionForm

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandex_lyceum_secret_key'


@app.route('/<title>')
def template(title: str):
    return render_template("base.html", title=title)


@app.route('/training/<prof>')
def training(prof: str):
    return render_template("training.html", title=prof, prof=prof)


@app.route('/answer', methods=['GET', 'POST'])
def answer():
    form = QuestionForm()
    if form.validate_on_submit():
        dct = {
            'surname': form.surname.data,
            'name': form.name.data,
            'education': form.education.data,
            'profession': form.profession.data,
            'sex': form.sex.data,
            'motivation': form.motivation.data,
            'ready': form.ready.data,
        }
        return render_template('auto_answer.html', args=dct, form=None, title='Результаты анкеты')

    return render_template('auto_answer.html', title='Анкета', form=form)


@app.route('/login')
def decision():
    form = DecisionForm()
    if form.validate_on_submit():
        return redirect('/success')
    return render_template('decision.html', title='Аварийный доступ', form=form)


@app.route('/list_prof/<tag>')
def show_list(tag: str):
    lst = {
        'items': [
            'Инженер',
            'Строитель',
            'Учёный',
            'Ещё кто-то'
        ]
    }

    return render_template('list.html', title=tag, tag=tag, list=lst)


@app.route('/success')
def success():
    return 'Success'


if '__main__' == __name__:
    app.run(port=8080, host='127.0.0.1')
